"""Feature switches for TickAssist, controlled by the owner only.

Each add-on feature can be turned off, which hides it on the page and refuses
its API routes on the server.

Who can change them: only whoever holds the owner password. Its salted PBKDF2
hash lives in app/owner.json, which ships with the office build - it is not in
the database and there is no way to set or reset it from the app. The owner
sets it, and the office-wide default switches, with tools/owner-tools.bat on
the owner's own PC; that folder is left out of the office packages.

Per PC, the owner can override the office defaults from Settings > Features by
entering the password. Updates never touch data/, so an override survives.

This stops anyone using TickAssist normally from changing features. It is not
tamper-proofing against someone who edits the program files themselves.
"""

import hashlib
import hmac
import json
import os

# key, label, what it covers. Order is the order shown in Settings.
FEATURES = [
    ("calls", "Incoming calls from MAX",
     "Reads the incoming number from CXone MAX (and the /call screen pop) into Phone Number."),
    ("caller_type", "Contact Type from the MAX skill",
     "Sets Contact Type from the skill MAX shows, e.g. FI-Dealer Support = Dealer."),
    ("known_caller", "Known caller details",
     "Fills Contact Name, Contact Type and Dealer Company for a number already in the database."),
    ("case_from_max", "Case number from MAX",
     "Puts the Inbound Case Reference from the Call Triage panel into Case ID."),
    ("photos", "Photos",
     "Paste, store, copy and save photos with a ticket."),
    ("d365", "Dynamics 365 integration",
     "Sign in to D365, create cases and send notes. Off: New D365 Case opens the browser form as before."),
    ("merge", "Merge Databases",
     "Bring tickets, photos, lists and macros in from another TickAssist database."),
    ("sheet", "Google Sheets lookup",
     "Fills fields from rows of shared Google Sheets when an Imaging Package, serial number or other key is entered."),
    ("transfer", "Call transfer",
     "Sends the active call to a troubleshooting queue from the Transfer call panel."),
    ("polish", "AI Polish",
     "Clean up the note text with the configured LLM."),
]
KEYS = [k for k, _, _ in FEATURES]

APP_DIR = os.path.dirname(os.path.abspath(__file__))
OWNER_FILE = os.path.join(APP_DIR, "owner.json")

# Per-PC override in the settings table. "default" = follow owner.json.
OFF_SETTING = "features_off"
USE_DEFAULTS = "default"
MIN_PASSWORD = 6
_ITERATIONS = 300_000


# Settings the owner can ship to every PC (tools: "Copy this PC's settings").
# Secrets are left out, except the AI key when the owner opts in.
OFFICE_SETTING_KEYS = [
    "call_watch_enabled", "call_watch_match", "call_watch_ignore", "call_watch_rules",
    "d365_org_url", "d365_tenant_id", "d365_client_id", "d365_case_type",
    "d365_case_origin", "d365_case_extra", "d365_customer_mode", "d365_note_html",
    "llm_provider", "llm_model", "llm_api_key", "transfer_url",
    "required_rules", "software_devices", "sheet_sources", "update_url",
]
REV_SETTING = "office_rev"


def office_settings(owner=None):
    owner = load_owner() if owner is None else owner
    values = owner.get("settings") or {}
    return {k: str(v) for k, v in values.items() if k in OFFICE_SETTING_KEYS and v is not None}


def apply_push(db, owner=None):
    """When the owner has pushed (bumped "rev"), forget this PC's own feature
    choices and its own copies of the office settings, once. Returns True if
    it did."""
    owner = load_owner() if owner is None else owner
    try:
        rev = int(owner.get("rev") or 0)
        applied = int(db.get_settings().get(REV_SETTING) or 0)
    except (TypeError, ValueError):
        return False
    if rev <= applied:
        return False
    db.delete_settings([OFF_SETTING] + list(office_settings(owner)))
    db.update_settings({REV_SETTING: str(rev)})
    return True


def load_owner(path=None):
    """{"password": hash, "defaults": {key: bool}} from owner.json, or {}."""
    try:
        with open(path or OWNER_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_owner(data, path=None):
    tmp = (path or OWNER_FILE) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    os.replace(tmp, path or OWNER_FILE)


def _owner_off(owner):
    defaults = owner.get("defaults") or {}
    return {k for k in KEYS if defaults.get(k) is False}


def overridden(settings):
    raw = settings.get(OFF_SETTING)
    return raw is not None and raw != USE_DEFAULTS


# Features an edition cannot offer at all (the server fills this in; Lite has
# no database to merge into). They stay off whatever the owner or a PC chooses.
FORCED_OFF = set()


def off_set(settings, owner=None):
    if not overridden(settings):
        base = _owner_off(load_owner() if owner is None else owner)
    else:
        base = {k.strip() for k in (settings.get(OFF_SETTING) or "").split(",")
                if k.strip() in KEYS}
    return base | FORCED_OFF


def enabled(settings, key):
    return key not in off_set(settings)


def state(settings, owner=None):
    off = off_set(settings, owner)
    return {k: k not in off for k in KEYS}


def encode_off(states):
    """{key: bool} -> the stored comma list of switched-off keys."""
    return ",".join(k for k in KEYS if states.get(k) is False)


def hash_password(password, salt=None, iterations=_ITERATIONS):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256$%d$%s$%s" % (iterations, salt.hex(), digest.hex())


def verify_password(password, stored):
    try:
        algo, iterations, salt, digest = (stored or "").split("$")
        if algo != "pbkdf2_sha256":
            return False
        check = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                                    bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(check.hex(), digest)
    except (ValueError, TypeError):
        return False


def verify_owner(password):
    return verify_password(password, load_owner().get("password"))


def public(settings):
    owner = load_owner()
    return {
        "features": state(settings, owner),
        "list": [{"key": k, "label": label, "description": desc} for k, label, desc in FEATURES],
        "owner_set": bool(owner.get("password")),
        "overridden": overridden(settings),
    }

"""SQLite persistence layer for TickAssist.

Holds three things:
  * settings   - key/value store (LLM provider, API key, model)
  * dealers    - the list of recognised dealer companies
  * tickets    - a repository of previously generated service notes

Uses only the Python standard library so the tool stays fully portable.
A fresh connection is opened per operation, which keeps things thread-safe
under the threading HTTP server without any shared-connection locking.
"""

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timedelta

# User-managed lookup lists. Each key is also its table name; the values are the
# defaults seeded into a brand-new (empty) table. All three behave identically
# (recognized dealers, device types, Reco units) and share the generic
# list_items / add_item / delete_item methods below.
# Lists the users cannot change: the values below ARE the list, and only a new
# version of TickAssist adds to them (the Settings panels show no Add/Remove).
FIXED_LISTS = {
    "device_types": ["Promax", "ProOne", "ProSensor", "Server", "Workstation", "Romexis"],
    "reco_units": ["5810", "3600", "3620", "3630", "3650", "3660", "T2 2250"],
    "reco_os": ["CentOS", "Ubuntu"],
}

# System Environment lists that are NOT checked against the Google Sheets (the
# sheets write them in a way that reads badly in notes): anyone can add a value,
# and a value typed into a note is added on save.
FREE_ENV_LISTS = {"romexis_versions"}

MANAGED_LISTS = {
    "dealers": [
        "Henry Schein", "Patterson Dental", "Benco Dental",
        "Burkhart Dental", "Atlanta Dental",
    ],
    "device_types": FIXED_LISTS["device_types"],
    "reco_units": FIXED_LISTS["reco_units"],
    # System Environment lists: typable dropdowns in the note. They fill from
    # saved tickets the first time (see ENV_LIST_COLUMNS) and from each save.
    "os_versions": ["10", "11", "2016", "2019", "2022", "2025",
                    "Ventura 13", "Sonoma 14", "Sequoia 15", "Tahoe 26"],
    "device_firmware": [], "device_tool_versions": [], "didapi_versions": [],
    "romexis_versions": [], "imaging_packages": [],
    "reco_os": FIXED_LISTS["reco_os"], "reco_firmware": [],
}

# Managed list -> the ticket column it suggests values for.
ENV_LIST_COLUMNS = {
    "os_versions": "os_version", "device_firmware": "device_firmware",
    "device_tool_versions": "device_tool_version", "didapi_versions": "didapi",
    "romexis_versions": "romexis", "imaging_packages": "imaging_package",
    "reco_os": "reco_os", "reco_firmware": "reco_firmware",
}

DEFAULT_SETTINGS = {
    "llm_provider": "gemini",
    "llm_api_key": "",
    "llm_model": "gemini-2.5-flash",
    # Incoming-call detection (see callwatch.py). On by default: it only ever
    # fills an empty Phone Number field, so it cannot overwrite a note.
    "call_watch_enabled": "1",
    "call_watch_match": "MAX, niceincontact, CXone, Mpower",
    "call_watch_ignore": "",
    # Google Sheet lookup (see sheets.py): typing an Imaging Package number fills
    # the other fields from that row of a shared Google Sheet.
    # Where Transfer call POSTs (the old Call Triage page's signal.php).
    "transfer_url": "",
    # Required fields (app.js "required fields"): rules that block Save until
    # named fields are filled, and the device types that count as software.
    "required_rules": json.dumps([
        {"kind": "always", "value": "", "fields": ["contact", "phone", "deviceType"],
         "during": "First Impressions"},
        {"kind": "hardware", "value": "", "fields": ["serialNumber"],
         "during": "First Impressions"},
        {"kind": "hardware", "value": "",
         "fields": ["serialNumber", "osVersion", "deviceFirmware"],
         "during": "Troubleshooting"},
    ], separators=(",", ":")),
    "software_devices": "Workstation, Server, Romexis",
    "sheet_url": "",
    # Where this PC looks for program updates (see updater.py).
    "update_url": "",   # empty = DEFAULT_UPDATE_URL (server.py)
    # JSON list of every sheet (see sheets.sources); empty = the single sheet above.
    "sheet_sources": "",
    "sheet_key_column": "Imaging Package",
    "sheet_map": "",
    "sheet_overwrite": "0",
    # Outline note values that differ from the sheet row for the Imaging Package.
    "sheet_check": "1",
    # "text in MAX = Contact Type", one per line; see callwatch.parse_rules.
    # Dynamics 365 (see d365.py). The refresh token is never sent to the page.
    "d365_org_url": "https://planmecausprod.crm.dynamics.com",
    "d365_tenant_id": "",
    "d365_client_id": "",
    "d365_refresh_token": "",
    "d365_user": "",
    "d365_case_type": "",
    "d365_case_origin": "",
    "d365_case_extra": "",
    "d365_customer_mode": "account",
    "d365_note_html": "1",
    "call_watch_rules": "Dealer = Dealer\nIT = IT\nSales = Sales\nMilitary = Military\nEnd User = End User",
    # Feature switches (see features.py): this PC's switched-off keys, or
    # "default" to follow the office defaults in app/owner.json. The owner
    # password is not stored here at all.
    "features_off": "default",
    # Last owner "push" this PC has applied (features.apply_push).
    "office_rev": "0",
}

OLD_REQUIRED_DEFAULT = '[{"kind":"hardware","value":"","fields":["serialNumber","osVersion","deviceFirmware"]}]'

# Columns persisted for each saved ticket. Frontend sends/receives these keys.
TICKET_FIELDS = [
    "case_number", "case_title", "call_type", "contact", "contact_type", "phone",
    "dealer_name", "os_name", "os_version", "device_type", "serial_number",
    "device_firmware", "device_tool_version", "didapi", "romexis",
    "imaging_package", "reco_os", "reco_pc", "reco_firmware", "error_info",
    "part_rec", "problem", "workflow", "next_steps", "res_status", "outcome",
    "note_text",
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS dealers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT UNIQUE NOT NULL COLLATE NOCASE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS device_types (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT UNIQUE NOT NULL COLLATE NOCASE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reco_units (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT UNIQUE NOT NULL COLLATE NOCASE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS macros (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    trigger    TEXT UNIQUE NOT NULL COLLATE NOCASE,
    expansion  TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tickets (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    case_number         TEXT,
    case_title          TEXT,
    call_type           TEXT,
    contact             TEXT,
    contact_type        TEXT,
    phone               TEXT,
    dealer_name         TEXT,
    os_name             TEXT,
    os_version          TEXT,
    device_type         TEXT,
    serial_number       TEXT,
    device_firmware     TEXT,
    device_tool_version TEXT,
    didapi              TEXT,
    romexis             TEXT,
    imaging_package     TEXT,
    reco_os             TEXT,
    reco_pc             TEXT,
    reco_firmware       TEXT,
    error_info          TEXT,
    part_rec            TEXT,
    problem             TEXT,
    workflow            TEXT,
    next_steps          TEXT,
    res_status          TEXT,
    outcome             TEXT,
    note_text           TEXT,
    created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Photos for a ticket. ticket_id NULL is the unsaved form's draft set; saving
-- the ticket claims them. Deleting a ticket deletes its photos.
CREATE TABLE IF NOT EXISTS photos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id   INTEGER REFERENCES tickets(id) ON DELETE CASCADE,
    name        TEXT NOT NULL DEFAULT '',
    mime        TEXT NOT NULL,
    width       INTEGER,
    height      INTEGER,
    size        INTEGER NOT NULL,
    data        BLOB NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_photos_ticket ON photos(ticket_id);
"""

SCHEMA += "".join(
    f"CREATE TABLE IF NOT EXISTS {t} (id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "name TEXT UNIQUE NOT NULL COLLATE NOCASE, "
    "created_at TEXT NOT NULL DEFAULT (datetime('now')));\n"
    for t in ENV_LIST_COLUMNS)

# Columns added after the first release; applied to existing DBs on startup.
TICKET_MIGRATIONS = {
    "next_steps": "ALTER TABLE tickets ADD COLUMN next_steps TEXT",
    "device_firmware": "ALTER TABLE tickets ADD COLUMN device_firmware TEXT",
    "device_tool_version":
        "ALTER TABLE tickets ADD COLUMN device_tool_version TEXT",
    "reco_firmware": "ALTER TABLE tickets ADD COLUMN reco_firmware TEXT",
    "call_type": "ALTER TABLE tickets ADD COLUMN call_type TEXT",
    "reco_os": "ALTER TABLE tickets ADD COLUMN reco_os TEXT",
}

PHOTO_MIGRATIONS = {
    "d365_sent_at": "ALTER TABLE photos ADD COLUMN d365_sent_at TEXT",
}

# The two rotations a note can come from. The generator carries a standing
# toggle rather than a per-note dropdown: a tech is on one rotation all day.
FIRST_IMPRESSIONS = "First Impressions"
TROUBLESHOOTING = "Troubleshooting"
CALL_TYPES = [FIRST_IMPRESSIONS, TROUBLESHOOTING]

# Earlier builds stored the singular. Normalised on write and migrated on
# startup so the two never coexist as separate categories.
LEGACY_CALL_TYPES = {"First Impression": FIRST_IMPRESSIONS}

# A troubleshooting call is a longer, heavier piece of work than an intake
# call, so raw volume understates a troubleshooting day. This is the exchange
# rate used for the workload figures ONLY - every raw count stays a raw count.
TROUBLESHOOTING_WEIGHT = 3

# Canonical resolution statuses in display order (mirrors the frontend select).
# Any stored status outside this list is appended after these on the dashboard.
STATUS_ORDER = [
    "Resolved", "Awaiting Information", "Escalated for Troubleshooting",
    "Escalated to Dealer", "Escalated to IT", "Escalated to After Sales",
    "Escalated to Third Party",
]

# SQLite's strftime('%w') is 0=Sunday. Reported Monday-first: a support week
# reads Mon-Fri, and the weekend rows drop out entirely when nobody worked them.
WEEKDAY_ORDER = [("1", "Mon"), ("2", "Tue"), ("3", "Wed"), ("4", "Thu"),
                 ("5", "Fri"), ("6", "Sat"), ("0", "Sun")]

# Windows the headline tiles can be read over. Each is a number of local days
# counting back from today inclusive; None means every ticket ever saved. All
# four are computed on every request and shipped together, so switching between
# them on the dashboard is instant and needs no second query.
TILE_RANGES = [("1d", 1), ("7d", 7), ("30d", 30), ("all", None)]
DEFAULT_TILE_RANGE = "all"


def _norm_status(status):
    """Fold legacy / blank statuses into 'Resolved' (matches the frontend)."""
    s = (status or "").strip()
    if not s or s == "Completed":
        return "Resolved"
    return s


def _window_figures(status_grid, dim_grids, since, today_iso, top):
    """Everything the dashboard shows for one time window.

    `since` is an inclusive local-date floor, or None for every ticket ever
    saved. Both the headline numbers and each panel list are built from the
    same day-grained grids, so a window can never disagree with itself.

    Counts and rates simply cover the window. The per-day average divides by
    finished days only, since today is still in progress - the same rule the
    weekday panel uses - falling back to the partial day when that is all the
    window holds. `busiest` is a maximum, so today counts there.
    """
    in_window = lambda d: since is None or d >= since

    rows = [r for r in status_grid if in_window(r["d"])]
    total = sum(r["c"] for r in rows)

    counts, by_call, per_day = {}, {}, {}
    for r in rows:
        key = _norm_status(r["k"])
        counts[key] = counts.get(key, 0) + r["c"]
        split = by_call.setdefault(key, {})
        call_type = r["ct"] or ""
        split[call_type] = split.get(call_type, 0) + r["c"]
        per_day[r["d"]] = per_day.get(r["d"], 0) + r["c"]

    resolved = counts.get("Resolved", 0)
    escalated = sum(v for k, v in counts.items() if k.startswith("Escalated"))

    # Canonical order first, anything unrecognised after it.
    status = [{"name": k, "count": counts[k]}
              for k in STATUS_ORDER if counts.get(k)]
    status += [{"name": k, "count": c} for k, c in counts.items()
               if k not in STATUS_ORDER and c]

    # Escalation destinations as short labels, each split by rotation.
    targets = {}
    for name, count in counts.items():
        for prefix in ("Escalated to ", "Escalated for "):
            if name.startswith(prefix):
                split = by_call.get(name, {})
                targets[name[len(prefix):]] = {
                    "count": count,
                    "first_impressions": split.get(FIRST_IMPRESSIONS, 0),
                    "troubleshooting": split.get(TROUBLESHOOTING, 0),
                }
                break
    escalation_targets = [
        dict(name=n, **vals) for n, vals in
        sorted(targets.items(), key=lambda x: (-x[1]["count"], x[0]))
    ]

    def dimension(col, limit=None):
        agg = {}
        for r in dim_grids[col]:
            if in_window(r["d"]):
                agg[r["k"]] = agg.get(r["k"], 0) + r["c"]
        ranked = sorted(agg.items(), key=lambda kv: (-kv[1], kv[0].lower()))
        rows = [{"name": k, "count": c} for k, c in ranked]
        return rows[:limit] if limit else rows

    finished = {d: n for d, n in per_day.items() if d != today_iso} or per_day
    active_days = len(finished)
    busiest = max(per_day.items(), key=lambda kv: kv[1]) if per_day else None

    pct = lambda n: round(n / total * 100) if total else 0
    return {
        "total": total,
        "resolved": resolved,
        "awaiting": counts.get("Awaiting Information", 0),
        "escalated": escalated,
        "resolution_rate": pct(resolved),
        "escalation_rate": pct(escalated),
        "active_days": active_days,
        "avg_per_active_day": (round(sum(finished.values()) / active_days, 1)
                               if active_days else 0),
        "busiest": ({"date": busiest[0], "count": busiest[1]}
                    if busiest else {"date": "", "count": 0}),
        "status": status,
        "escalation_targets": escalation_targets,
        "call_types": dimension("call_type"),
        "contact_types": dimension("contact_type"),
        "device_types": dimension("device_type", top),
        "dealers": dimension("dealer_name", top),
    }


# Merging an older database. Two shapes are recognised: an earlier TickAssist
# (same column names, possibly fewer of them) and the older desktop Tickasist,
# whose tickets table used a different vocabulary entirely. Anything else is
# rejected rather than guessed at.
LEGACY_DESKTOP_MAP = {
    "case_id": "case_number",
    "contact": "contact",
    "contact_type": "contact_type",
    "dealer": "dealer_name",
    "device": "device_type",
    "serial": "serial_number",
    "romexis": "romexis",
    "didapi": "didapi",
    "img_pkg": "imaging_package",
    "parts": "part_rec",
    "prob": "problem",
    "err": "error_info",
    "work": "workflow",
    "reso": "outcome",
    "status": "res_status",
}

# Filenames a merge source might actually be, in the order they are tried.
MERGE_CANDIDATES = [
    os.path.join("data", "tickassist.db"),
    "tickassist.db",
    os.path.join("Data", "detailed_log.db"),
    "detailed_log.db",
]


class MergeError(Exception):
    """Raised when a merge source cannot be read or understood."""


def _row_fingerprint(row):
    """Content identity for a ticket, used to skip rows already present.

    Deliberately the whole row rather than (date, case number): one case can
    hold several notes, and two notes of the same case saved in the same second
    are not the same note.
    """
    return "".join((row.get(f) or "").strip() for f in
                        ["created_at"] + TICKET_FIELDS)


class ListItemExistsError(Exception):
    """Raised when adding a managed-list item whose name already exists."""


class MacroExistsError(Exception):
    """Raised when adding a macro whose trigger already exists."""


class Database:
    def __init__(self, path):
        self.path = path
        # Office-wide settings from app/owner.json (set by the server). They
        # sit between the built-in defaults and what this PC saved itself.
        self.office_defaults = {}
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._init()

    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _init(self):
        with self._connect() as conn:
            conn.executescript(SCHEMA)
            # Apply column additions to pre-existing ticket tables.
            existing = {r[1] for r in
                        conn.execute("PRAGMA table_info(tickets)").fetchall()}
            for column, ddl in TICKET_MIGRATIONS.items():
                if column not in existing:
                    conn.execute(ddl)
            existing = {r[1] for r in
                        conn.execute("PRAGMA table_info(photos)").fetchall()}
            for column, ddl in PHOTO_MIGRATIONS.items():
                if column not in existing:
                    conn.execute(ddl)
            # Fold any legacy call-type spelling into the current one. Cheap,
            # idempotent, and it catches rows written by an older tab that was
            # still open when the app was updated.
            for old, new in LEGACY_CALL_TYPES.items():
                conn.execute(
                    "UPDATE tickets SET call_type = ? WHERE call_type = ?",
                    (new, old),
                )
            # Seed default settings only for keys that do not exist yet.
            for key, value in DEFAULT_SETTINGS.items():
                conn.execute(
                    "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                    (key, value),
                )
            # 4.32 shipped one required-fields rule for every call type; swap
            # that untouched default for the per-rotation one.
            conn.execute("UPDATE settings SET value = ? WHERE key = 'required_rules' AND value = ?",
                         (DEFAULT_SETTINGS["required_rules"], OLD_REQUIRED_DEFAULT))
            # Romexis is software too: widen the untouched old default.
            conn.execute("UPDATE settings SET value = ? WHERE key = 'software_devices' AND value = ?",
                         (DEFAULT_SETTINGS["software_devices"], "Workstation, Server"))
            # Seed each managed list's defaults only when its table is empty.
            for table, defaults in MANAGED_LISTS.items():
                count = conn.execute(
                    f"SELECT COUNT(*) FROM {table}"
                ).fetchone()[0]
                if count == 0:
                    conn.executemany(
                        f"INSERT OR IGNORE INTO {table} (name) VALUES (?)",
                        [(d,) for d in defaults],
                    )
            # Fixed lists always match the program exactly: anything else is
            # dropped and anything new in this version is added.
            for table, fixed in FIXED_LISTS.items():
                have = {r[0].lower(): r[0] for r in conn.execute(f"SELECT name FROM {table}")}
                for low, name in have.items():
                    if low not in {f.lower() for f in fixed}:
                        conn.execute(f"DELETE FROM {table} WHERE name = ?", (name,))
                for name in fixed:
                    if name.lower() not in have:
                        conn.execute(f"INSERT OR IGNORE INTO {table} (name) VALUES (?)", (name,))
            # The System Environment dropdowns start from what saved tickets
            # already hold (once), so they are useful on day one.
            if not conn.execute("SELECT 1 FROM settings WHERE key = 'env_lists_seeded'").fetchone():
                for table, col in ENV_LIST_COLUMNS.items():
                    if table in FIXED_LISTS:
                        continue
                    conn.execute(
                        f"INSERT OR IGNORE INTO {table} (name) "
                        f"SELECT DISTINCT TRIM({col}) FROM tickets "
                        f"WHERE {col} IS NOT NULL AND TRIM({col}) <> ''")
                conn.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('env_lists_seeded', '1')")

    # ---- settings -------------------------------------------------------
    def get_settings(self):
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM settings").fetchall()
        settings = dict(DEFAULT_SETTINGS)
        settings.update(self.office_defaults)
        for r in rows:
            key, value = r["key"], r["value"]
            # A value this PC saved that is just the built-in default (Save
            # writes every field) does not hide the office's value.
            if key in self.office_defaults and value == DEFAULT_SETTINGS.get(key):
                continue
            settings[key] = value
        return settings

    def delete_settings(self, keys):
        with self._connect() as conn:
            conn.executemany("DELETE FROM settings WHERE key = ?", [(k,) for k in keys])

    def update_settings(self, values):
        allowed = set(DEFAULT_SETTINGS.keys())
        with self._connect() as conn:
            for key, value in values.items():
                # None means "not provided" - a partial update must not blank
                # the stored value (empty string is an explicit clear).
                if key not in allowed or value is None:
                    continue
                conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (key, str(value)),
                )
        return self.get_settings()

    # ---- managed lists (dealers / device_types / reco_units) ------------
    @staticmethod
    def _list_table(key):
        # key is validated against the whitelist so it is safe to interpolate.
        if key not in MANAGED_LISTS:
            raise KeyError(key)
        return key

    def list_items(self, key):
        table = self._list_table(key)
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT id, name FROM {table} ORDER BY name COLLATE NOCASE"
            ).fetchall()
        return [dict(r) for r in rows]

    def add_item(self, key, name):
        table = self._list_table(key)
        name = (name or "").strip()
        if not name:
            raise ValueError("Name cannot be empty.")
        try:
            with self._connect() as conn:
                cur = conn.execute(
                    f"INSERT INTO {table} (name) VALUES (?)", (name,)
                )
                return {"id": cur.lastrowid, "name": name}
        except sqlite3.IntegrityError:
            raise ListItemExistsError(f"'{name}' already exists.")

    def delete_item(self, key, item_id):
        table = self._list_table(key)
        with self._connect() as conn:
            cur = conn.execute(f"DELETE FROM {table} WHERE id = ?", (item_id,))
            return cur.rowcount > 0

    # ---- macros ---------------------------------------------------------
    @staticmethod
    def normalize_trigger(trigger):
        """Strip leading backslashes; triggers are stored without the prefix."""
        return (trigger or "").lstrip("\\").strip()

    def list_macros(self):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, trigger, expansion FROM macros "
                "ORDER BY trigger COLLATE NOCASE"
            ).fetchall()
        return [dict(r) for r in rows]

    def add_macro(self, trigger, expansion):
        trigger = self.normalize_trigger(trigger)
        expansion = expansion if expansion is not None else ""
        if not trigger:
            raise ValueError("Trigger cannot be empty.")
        if not trigger.isalnum():
            raise ValueError("Trigger may only contain letters and numbers.")
        if not expansion.strip():
            raise ValueError("Expansion cannot be empty.")
        try:
            with self._connect() as conn:
                cur = conn.execute(
                    "INSERT INTO macros (trigger, expansion) VALUES (?, ?)",
                    (trigger, expansion),
                )
                return {"id": cur.lastrowid, "trigger": trigger,
                        "expansion": expansion}
        except sqlite3.IntegrityError:
            raise MacroExistsError(f"Macro '\\{trigger}' already exists.")

    def delete_macro(self, macro_id):
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM macros WHERE id = ?", (macro_id,))
            return cur.rowcount > 0

    # ---- tickets --------------------------------------------------------
    def list_tickets(self, search=None):
        # phone is listed so the repository table can show and search it.
        query = (
            "SELECT id, case_number, case_title, call_type, contact, "
            "contact_type, phone, dealer_name, res_status, created_at, "
            "(SELECT COUNT(*) FROM photos p WHERE p.ticket_id = tickets.id) "
            "AS photo_count FROM tickets"
        )
        params = []
        if search:
            like = f"%{search.strip()}%"
            query += (
                " WHERE case_number LIKE ? OR case_title LIKE ? OR contact LIKE ? "
                "OR problem LIKE ? OR dealer_name LIKE ? OR phone LIKE ? "
                "OR call_type LIKE ?"
            )
            params = [like] * 7
        query += " ORDER BY id DESC"
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def tickets_by_phone(self, phone, limit=5):
        """Earlier tickets sharing a phone number, newest first.

        Matched on digits alone, so a number typed any which way still finds
        one saved as 410-498-6464. Normalising in Python rather than SQL keeps
        it readable, and the table is small enough that it costs nothing.
        """
        digits = "".join(ch for ch in (phone or "") if ch.isdigit())
        if len(digits) < 7:            # too short to identify anyone
            return []
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, case_number, case_title, contact, contact_type, "
                "dealer_name, phone, problem, "
                "datetime(created_at, 'localtime') AS created_at "
                "FROM tickets WHERE TRIM(COALESCE(phone, '')) <> '' "
                "ORDER BY id DESC"
            ).fetchall()
        out = []
        for r in rows:
            stored = "".join(ch for ch in (r["phone"] or "") if ch.isdigit())
            if stored and (stored.endswith(digits) or digits.endswith(stored)):
                out.append(dict(r))
                if len(out) >= limit:
                    break
        return out

    def caller_card(self, phone, limit=3):
        """What the incoming-call card shows about a number already on file.

        Same digits-only matching as tickets_by_phone, but with the device and
        status columns the card wants, and a total count (the card says "7
        calls on file", not "5"). Newest first; limit rows are returned.
        """
        digits = "".join(ch for ch in (phone or "") if ch.isdigit())
        if len(digits) < 7:
            return {"count": 0, "tickets": []}
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, case_number, case_title, call_type, contact, "
                "contact_type, dealer_name, device_type, serial_number, "
                "problem, res_status, phone, "
                "datetime(created_at, 'localtime') AS created_at "
                "FROM tickets WHERE TRIM(COALESCE(phone, '')) <> '' "
                "ORDER BY id DESC"
            ).fetchall()
        out = []
        for r in rows:
            stored = "".join(ch for ch in (r["phone"] or "") if ch.isdigit())
            if stored and (stored.endswith(digits) or digits.endswith(stored)):
                row = dict(r)
                row.pop("phone", None)
                out.append(row)
        return {"count": len(out), "tickets": out[:limit]}

    def get_ticket(self, ticket_id):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM tickets WHERE id = ?", (ticket_id,)
            ).fetchone()
        return dict(row) if row else None

    @staticmethod
    def _normalize(data):
        """Fold a legacy call-type spelling coming from a stale browser tab."""
        call_type = data.get("call_type")
        if call_type in LEGACY_CALL_TYPES:
            data = dict(data, call_type=LEGACY_CALL_TYPES[call_type])
        return data

    def save_ticket(self, data):
        data = self._normalize(data)
        values = [data.get(f, "") or "" for f in TICKET_FIELDS]
        columns = ", ".join(TICKET_FIELDS)
        placeholders = ", ".join(["?"] * len(TICKET_FIELDS))
        with self._connect() as conn:
            cur = conn.execute(
                f"INSERT INTO tickets ({columns}) VALUES ({placeholders})",
                values,
            )
            ticket_id = cur.lastrowid
        return self.get_ticket(ticket_id)

    def update_ticket(self, ticket_id, data):
        """Overwrite an existing ticket in place; None if the id is unknown."""
        data = self._normalize(data)
        values = [data.get(f, "") or "" for f in TICKET_FIELDS]
        assignments = ", ".join(f"{f} = ?" for f in TICKET_FIELDS)
        with self._connect() as conn:
            cur = conn.execute(
                f"UPDATE tickets SET {assignments} WHERE id = ?",
                values + [ticket_id],
            )
            if cur.rowcount == 0:
                return None
        return self.get_ticket(ticket_id)

    def all_tickets(self):
        """Every column of every ticket, newest first (for CSV export).

        created_at is converted to local time here so the exported file
        matches what the user sees in the UI.
        """
        columns = ", ".join(TICKET_FIELDS)
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, datetime(created_at, 'localtime') AS created_at, "
                f"{columns} FROM tickets ORDER BY id DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    # ---- photos ----------------------------------------------------------
    PHOTO_COLUMNS = ("id, ticket_id, name, mime, width, height, size, created_at, "
                     "d365_sent_at")

    def list_photos(self, ticket_id=None):
        """A ticket's photos, or the draft set when ticket_id is None."""
        with self._connect() as conn:
            if ticket_id is None:
                rows = conn.execute(
                    "SELECT %s FROM photos WHERE ticket_id IS NULL ORDER BY id"
                    % self.PHOTO_COLUMNS).fetchall()
            else:
                rows = conn.execute(
                    "SELECT %s FROM photos WHERE ticket_id = ? ORDER BY id"
                    % self.PHOTO_COLUMNS, (ticket_id,)).fetchall()
        return [dict(r) for r in rows]

    def add_photo(self, ticket_id, name, mime, data, width=None, height=None):
        with self._connect() as conn:
            if ticket_id is not None and not conn.execute(
                    "SELECT 1 FROM tickets WHERE id = ?", (ticket_id,)).fetchone():
                return None
            cur = conn.execute(
                "INSERT INTO photos (ticket_id, name, mime, width, height, size, data) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (ticket_id, (name or "")[:200], mime, width, height, len(data),
                 sqlite3.Binary(data)))
            row = conn.execute("SELECT %s FROM photos WHERE id = ?"
                               % self.PHOTO_COLUMNS, (cur.lastrowid,)).fetchone()
        return dict(row)

    def get_photo(self, photo_id):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM photos WHERE id = ?",
                               (photo_id,)).fetchone()
        return dict(row) if row else None

    def delete_photo(self, photo_id):
        with self._connect() as conn:
            return conn.execute("DELETE FROM photos WHERE id = ?",
                                (photo_id,)).rowcount > 0

    def claim_draft_photos(self, ticket_id):
        """Attach the draft set to a ticket that was just saved."""
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM tickets WHERE id = ?",
                                (ticket_id,)).fetchone():
                return 0
            return conn.execute("UPDATE photos SET ticket_id = ? WHERE ticket_id IS NULL",
                                (ticket_id,)).rowcount

    def copy_photos(self, from_id, to_id):
        """Give a ticket saved as a copy the original's photos too."""
        with self._connect() as conn:
            return conn.execute(
                "INSERT INTO photos (ticket_id, name, mime, width, height, size, data) "
                "SELECT ?, name, mime, width, height, size, data FROM photos "
                "WHERE ticket_id = ? ORDER BY id", (to_id, from_id)).rowcount

    def mark_photos_sent(self, ids):
        """Remember which photos went to D365, so they aren't offered twice."""
        with self._connect() as conn:
            for pid in ids:
                conn.execute("UPDATE photos SET d365_sent_at = datetime('now') WHERE id = ?",
                             (pid,))

    def discard_draft_photos(self):
        with self._connect() as conn:
            return conn.execute("DELETE FROM photos WHERE ticket_id IS NULL").rowcount

    def delete_ticket(self, ticket_id):
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM tickets WHERE id = ?", (ticket_id,))
            return cur.rowcount > 0

    # ---- merging an older database --------------------------------------
    @staticmethod
    def resolve_merge_source(path):
        """Turn what the user typed into an actual database file.

        Accepts the .db itself or the folder it lives in - a previous
        TickAssist directory, or the old desktop app's folder.
        """
        path = os.path.expandvars(os.path.expanduser((path or "").strip().strip('"')))
        if not path:
            raise MergeError("Enter the folder or .db file to merge from.")
        if os.path.isfile(path):
            return os.path.abspath(path)
        if os.path.isdir(path):
            for rel in MERGE_CANDIDATES:
                candidate = os.path.join(path, rel)
                if os.path.isfile(candidate):
                    return os.path.abspath(candidate)
            raise MergeError(
                "No TickAssist database found in that folder (looked for "
                + ", ".join(MERGE_CANDIDATES) + ").")
        raise MergeError("No such file or folder: " + path)

    def _read_source(self, db_path):
        """Rows from a source database, mapped onto our own columns."""
        if os.path.abspath(db_path) == os.path.abspath(self.path):
            raise MergeError("That is the database this app is already using.")
        try:
            conn = sqlite3.connect("file:%s?mode=ro" % db_path.replace("?", "%3f"),
                                   uri=True)
            conn.row_factory = sqlite3.Row
            columns = {r[1] for r in
                       conn.execute("PRAGMA table_info(tickets)").fetchall()}
            if not columns:
                raise MergeError("That file has no tickets table - "
                                 "it does not look like a TickAssist database.")
            rows = conn.execute("SELECT * FROM tickets").fetchall()
            conn.close()
        except sqlite3.DatabaseError:
            raise MergeError("That file is not a readable SQLite database.")

        native = "case_number" in columns
        legacy = "case_id" in columns and "prob" in columns
        if not (native or legacy):
            raise MergeError("Unrecognised tickets table - neither a TickAssist "
                             "nor an older Tickasist database.")

        mapped = []
        for row in rows:
            data = dict(row)
            out = {"created_at": (data.get("created_at") or
                                  data.get("timestamp") or ""),
                   # Its id there, so its photos can follow it here.
                   "_src_id": data.get("id")}
            if native:
                for field in TICKET_FIELDS:
                    out[field] = data.get(field) or ""
            else:
                for field in TICKET_FIELDS:
                    out[field] = ""
                for src, dest in LEGACY_DESKTOP_MAP.items():
                    if src in columns:
                        out[dest] = data.get(src) or ""
                # The desktop app split the OS across two columns.
                for src, name in (("win", "Windows"), ("mac", "macOS")):
                    value = (data.get(src) or "").strip()
                    if value and value.lower() != "none":
                        out["os_name"] = name
                        out["os_version"] = value
                        break
                # Its queue has no column here; keep it rather than lose it.
                queue = (data.get("queue") or "").strip()
                if queue and not out["case_title"]:
                    out["case_title"] = queue
            out["call_type"] = LEGACY_CALL_TYPES.get(out.get("call_type"),
                                                     out.get("call_type", ""))
            mapped.append(out)
        return mapped, ("TickAssist" if native else "Tickasist (desktop)")

    @staticmethod
    def _open_source(db_path):
        conn = sqlite3.connect("file:%s?mode=ro" % db_path.replace("?", "%3f"), uri=True)
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _table_columns(conn, table):
        return {r[1] for r in conn.execute("PRAGMA table_info(%s)" % table).fetchall()}

    def _merge_plan(self, path):
        """Everything a merge from `path` would bring in, without doing any of it.

        Tickets are matched on their whole content, so a ticket already here is
        never doubled. Photos follow their ticket - onto the new copy, or onto
        the matching ticket already here when it lacks them. Dealer, device and
        Reco lists and macros are added where missing; where both databases
        have a macro with the same trigger, this one's is kept.
        """
        source = self.resolve_merge_source(path)
        rows, kind = self._read_source(source)
        with self._connect() as conn:
            existing = {}
            for r in conn.execute(
                    "SELECT id, datetime(created_at) AS created_at, %s FROM tickets"
                    % ", ".join(TICKET_FIELDS)).fetchall():
                existing.setdefault(_row_fingerprint(dict(r)), r["id"])
        fresh, seen, target = [], {}, {}
        for row in rows:
            fp = _row_fingerprint(row)
            if fp in existing:
                target[row.get("_src_id")] = ("old", existing[fp])
            elif fp in seen:
                target[row.get("_src_id")] = ("new", seen[fp])
            else:
                seen[fp] = len(fresh)
                target[row.get("_src_id")] = ("new", len(fresh))
                fresh.append(row)
        plan = {"source": source, "kind": kind, "rows": fresh, "total": len(rows),
                "photos": [], "photos_skipped": 0, "lists": {}, "macros": [],
                "macros_kept": 0}

        src = self._open_source(source)
        try:
            # Photos: only those belonging to a ticket (drafts stay behind), and
            # not ones the matching ticket here already has, byte for byte.
            if self._table_columns(src, "photos"):
                old_ids = sorted({t[1] for t in target.values() if t[0] == "old"})
                have = set()
                with self._connect() as conn:
                    for i in range(0, len(old_ids), 500):
                        chunk = old_ids[i:i + 500]
                        for r in conn.execute(
                                "SELECT ticket_id, data FROM photos WHERE ticket_id IN (%s)"
                                % ",".join("?" * len(chunk)), chunk):
                            have.add((("old", r["ticket_id"]), hashlib.sha1(r["data"]).hexdigest()))
                for r in src.execute("SELECT id, ticket_id, data FROM photos "
                                     "WHERE ticket_id IS NOT NULL ORDER BY id"):
                    dest = target.get(r["ticket_id"])
                    if dest is None:
                        continue
                    key = (dest, hashlib.sha1(r["data"]).hexdigest())
                    if key in have:
                        plan["photos_skipped"] += 1
                        continue
                    have.add(key)
                    plan["photos"].append((r["id"], dest))
            with self._connect() as conn:
                for key in MANAGED_LISTS:
                    if key in FIXED_LISTS:
                        continue
                    table = key
                    if not self._table_columns(src, table):
                        continue
                    mine = {r[0].strip().lower() for r in conn.execute(f"SELECT name FROM {table}")}
                    new = []
                    for r in src.execute(f"SELECT name FROM {table} ORDER BY name"):
                        name = (r[0] or "").strip()
                        if name and name.lower() not in mine:
                            mine.add(name.lower())
                            new.append(name)
                    if new:
                        plan["lists"][key] = new
                if self._table_columns(src, "macros"):
                    mine = {r[0].lower(): r[1] for r in
                            conn.execute("SELECT trigger, expansion FROM macros")}
                    for r in src.execute("SELECT trigger, expansion FROM macros ORDER BY trigger"):
                        trig = (r[0] or "").strip()
                        if not trig:
                            continue
                        if trig.lower() in mine:
                            if (mine[trig.lower()] or "") != (r[1] or ""):
                                plan["macros_kept"] += 1
                            continue
                        mine[trig.lower()] = r[1]
                        plan["macros"].append((trig, r[1] or ""))
        except sqlite3.DatabaseError:
            raise MergeError("Part of that database could not be read.")
        finally:
            src.close()
        return plan

    @staticmethod
    def _merge_summary(plan):
        fresh = plan["rows"]
        dates = sorted(r["created_at"][:10] for r in fresh if r["created_at"])
        lists = {k: len(v) for k, v in plan["lists"].items()}
        return {
            "source": plan["source"],
            "kind": plan["kind"],
            "total": plan["total"],
            "new": len(fresh),
            "duplicates": plan["total"] - len(fresh),
            "earliest": dates[0] if dates else "",
            "latest": dates[-1] if dates else "",
            "photos": len(plan["photos"]),
            "photos_skipped": plan["photos_skipped"],
            "lists": lists,
            "macros": len(plan["macros"]),
            "macros_kept": plan["macros_kept"],
            "anything": bool(fresh or plan["photos"] or lists or plan["macros"]),
        }

    def merge_preview(self, path):
        """What a merge from `path` would do, without doing any of it."""
        return self._merge_summary(self._merge_plan(path))

    def merge_apply(self, path):
        """Merge `path` in, after taking a snapshot of the current database."""
        plan = self._merge_plan(path)
        result = self._merge_summary(plan)
        result["added"] = 0
        result["backup"] = ""
        if not result["anything"]:
            return result

        # Second-resolution stamps collide if two merges run back to back, and
        # VACUUM INTO refuses to overwrite - so make the name unique.
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        folder = os.path.dirname(os.path.abspath(self.path))
        backup = os.path.join(folder, "tickassist-premerge-%s.db" % stamp)
        suffix = 2
        while os.path.exists(backup):
            backup = os.path.join(folder,
                                  "tickassist-premerge-%s-%d.db" % (stamp, suffix))
            suffix += 1
        columns = ["created_at"] + TICKET_FIELDS
        placeholders = ", ".join(["?"] * len(columns))
        with self._connect() as conn:
            conn.execute("VACUUM INTO ?", (backup,))
        src = self._open_source(plan["source"])
        try:
            photo_cols = self._table_columns(src, "photos")
            sent_col = "d365_sent_at" if "d365_sent_at" in photo_cols else "NULL"
            with self._connect() as conn:
                new_ids = []
                for row in plan["rows"]:
                    cur = conn.execute(
                        "INSERT INTO tickets (%s) VALUES (%s)"
                        % (", ".join(columns), placeholders),
                        [row.get(c) or "" for c in columns])
                    new_ids.append(cur.lastrowid)
                for src_id, (where, ref) in plan["photos"]:
                    p = src.execute(
                        "SELECT name, mime, width, height, size, data, created_at, "
                        "%s AS sent FROM photos WHERE id = ?" % sent_col, (src_id,)).fetchone()
                    if p is None:
                        continue
                    conn.execute(
                        "INSERT INTO photos (ticket_id, name, mime, width, height, size, "
                        "data, created_at, d365_sent_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (new_ids[ref] if where == "new" else ref, p["name"] or "", p["mime"],
                         p["width"], p["height"], p["size"], p["data"],
                         p["created_at"] or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                         p["sent"]))
                for key, names in plan["lists"].items():
                    conn.executemany(
                        f"INSERT OR IGNORE INTO {key} (name) VALUES (?)",
                        [(n,) for n in names])
                conn.executemany(
                    "INSERT OR IGNORE INTO macros (trigger, expansion) VALUES (?, ?)",
                    plan["macros"])
        finally:
            src.close()
        result["added"] = result["new"]
        result["backup"] = backup
        return result

    # ---- dashboard ------------------------------------------------------
    def dashboard_stats(self, days=30, top=8):
        """Aggregate counts for the Insights page, computed in SQL.

        Everything is derived from the saved tickets - no extra data is
        collected. created_at is bucketed in local time so "today" matches
        what the user sees; the daily series is zero-filled for `days` days.

        Every panel is computed for each selectable window and shipped in one
        response, so a panel can be re-scoped on the page without another
        query. The top-level keys mirror the all-time window, which is what an
        older frontend reads.
        """
        def _dim_grid(conn, col):
            # value counts per local day, for one dimension.
            return conn.execute(
                f"SELECT date(created_at, 'localtime') AS d, {col} AS k, "
                f"COUNT(*) AS c FROM tickets "
                f"WHERE TRIM(COALESCE({col}, '')) <> '' GROUP BY d, k"
            ).fetchall()

        with self._connect() as conn:
            # Status x rotation x day: the grid behind the headline figures,
            # the resolution panel and the escalation split alike.
            status_grid = conn.execute(
                "SELECT date(created_at, 'localtime') AS d, res_status AS k, "
                "call_type AS ct, COUNT(*) AS c FROM tickets GROUP BY d, k, ct"
            ).fetchall()
            dim_grids = {col: _dim_grid(conn, col) for col in
                         ("call_type", "contact_type", "device_type",
                          "dealer_name")}
            # Per-day totals plus the call-type split, so the volume series can
            # be shown as one trend and as a rotation each.
            daily_rows = conn.execute(
                "SELECT date(created_at, 'localtime') AS d, COUNT(*) AS c, "
                "SUM(CASE WHEN call_type = ? THEN 1 ELSE 0 END) AS fi, "
                "SUM(CASE WHEN call_type = ? THEN 1 ELSE 0 END) AS ts "
                "FROM tickets GROUP BY d", CALL_TYPES
            ).fetchall()
            # Intensity by day of week. Three corrections are needed before
            # the days are comparable: the weekdays have not all come round the
            # same number of times, a troubleshooting call is heavier than an
            # intake call so raw volume flatters a First Impressions day, and
            # today is still in progress - a half-finished day averaged in with
            # finished ones drags its weekday down for no real reason.
            weekday_sql = (
                "SELECT strftime('%w', created_at, 'localtime') AS w, "
                "COUNT(*) AS c, "
                "COUNT(DISTINCT date(created_at, 'localtime')) AS d, "
                "SUM(CASE WHEN call_type = ? THEN ? ELSE 1 END) AS load "
                "FROM tickets {where} GROUP BY w"
            )
            weight = (TROUBLESHOOTING, TROUBLESHOOTING_WEIGHT)
            weekday_rows = conn.execute(weekday_sql.format(
                where="WHERE date(created_at, 'localtime') "
                      "<> date('now', 'localtime')"), weight).fetchall()
            # First day of use: excluding today would leave nothing at all, so
            # report the partial day rather than an empty panel.
            if not weekday_rows:
                weekday_rows = conn.execute(
                    weekday_sql.format(where=""), weight).fetchall()

        # Zero-filled daily series for the last `days` local days.
        by_day = {r["d"]: r for r in daily_rows}
        today = datetime.now().date()
        today_iso = today.isoformat()
        daily, recent7 = [], 0
        for i in range(days - 1, -1, -1):
            key = (today - timedelta(days=i)).isoformat()
            row = by_day.get(key)
            count = row["c"] if row else 0
            daily.append({
                "date": key,
                "count": count,
                "first_impression": (row["fi"] or 0) if row else 0,
                "troubleshooting": (row["ts"] or 0) if row else 0,
            })
            if i < 7:
                recent7 += count

        # Day-of-week intensity. `avg` is plain notes per worked day; `load`
        # and `load_avg` are the same figures weighted by call type. The raw
        # numbers are kept so the weighted ones can be shown against them.
        # load_avg keeps two decimals: it is a derived index rather than a
        # count of anything, so rounding it to a whole number would throw away
        # the very precision that separates two days of equal call volume.
        by_weekday = {r["w"]: r for r in weekday_rows}
        weekdays = []
        for key, name in WEEKDAY_ORDER:
            row = by_weekday.get(key)
            if not row or not row["d"]:
                continue
            load = row["load"] or 0
            weekdays.append({"name": name, "count": row["c"],
                             "days": row["d"],
                             "avg": round(row["c"] / row["d"], 1),
                             "load": load,
                             "load_avg": round(load / row["d"], 2)})

        # Every panel, for every window.
        ranges = {}
        for key, span in TILE_RANGES:
            since = (None if span is None
                     else (today - timedelta(days=span - 1)).isoformat())
            ranges[key] = _window_figures(status_grid, dim_grids, since,
                                          today_iso, top)

        # The all-time window doubles as the top level, so there is one set of
        # numbers rather than two that could drift apart.
        overall = ranges[DEFAULT_TILE_RANGE]
        payload = {
            "ranges": ranges,
            "range_order": [key for key, _ in TILE_RANGES],
            "default_range": DEFAULT_TILE_RANGE,
            "weekdays": weekdays,
            "troubleshooting_weight": TROUBLESHOOTING_WEIGHT,
            "recent7": recent7,
            "days": days,
            "daily": daily,
        }
        payload.update(overall)
        return payload
